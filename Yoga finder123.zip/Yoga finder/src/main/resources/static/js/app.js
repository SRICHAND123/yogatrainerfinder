const map = L.map('map').setView([12.9716, 77.5946], 13); // Default to Bangalore
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

let markers = [];

// Fetch and display trainers
async function fetchTrainers(query = '') {
    let url = '/api/trainers';
    if (query) {
        url = `/api/trainers/search?query=${query}`;
    }
    
    // If map bounds changed, we could use location search too
    // const center = map.getCenter();
    // url = `/api/trainers/search?lat=${center.lat}&lng=${center.lng}&radius=10`;

    const response = await fetch(url);
    const trainers = await response.json();
    
    updateMap(trainers);
    updateList(trainers);
}

function updateMap(trainers) {
    // Clear existing markers
    markers.forEach(m => map.removeLayer(m));
    markers = [];

    trainers.forEach(t => {
        if (t.location) {
            const marker = L.marker([t.location.y, t.location.x]).addTo(map);
            marker.bindPopup(`<b>${t.name}</b><br>${t.specialization}`);
            marker.on('click', () => showTrainerDetails(t));
            markers.push(marker);
        }
    });
}

function updateList(trainers) {
    const list = document.getElementById('trainersList');
    list.innerHTML = '';
    trainers.forEach(t => {
        const item = document.createElement('div');
        item.className = 'list-group-item trainer-card';
        item.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-1">${t.name}</h5>
                <small class="text-muted">⭐ ${t.averageRating.toFixed(1)}</small>
            </div>
            <p class="mb-1">${t.specialization}</p>
            <small>${t.address}</small>
        `;
        item.onclick = () => {
             map.flyTo([t.location.y, t.location.x], 15);
             showTrainerDetails(t);
        };
        list.appendChild(item);
    });
}

async function showTrainerDetails(trainer) {
    document.getElementById('detailName').innerText = trainer.name;
    document.getElementById('detailSpec').innerText = trainer.specialization;
    document.getElementById('detailExp').innerText = trainer.experience;
    document.getElementById('detailAddress').innerText = trainer.address;
    document.getElementById('detailRating').innerText = trainer.averageRating.toFixed(1);
    document.getElementById('detailReviews').innerText = trainer.totalReviews;
    document.getElementById('reviewTrainerId').value = trainer.id;

    // Fetch reviews
    const res = await fetch(`/api/reviews/trainer/${trainer.id}`);
    const reviews = await res.json();
    const reviewsDiv = document.getElementById('reviewList');
    reviewsDiv.innerHTML = reviews.map(r => `
        <div class="card p-2 mb-2">
            <strong>${r.userName} (${r.rating}⭐)</strong>
            <p class="mb-0 text-muted">${r.comment}</p>
        </div>
    `).join('');

    const modal = new bootstrap.Modal(document.getElementById('trainerDetailsModal'));
    modal.show();
}

// Add Trainer
document.getElementById('addTrainerForm').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
        name: document.getElementById('name').value,
        age: document.getElementById('age').value,
        gender: document.getElementById('gender').value,
        phone: document.getElementById('phone').value,
        specialization: document.getElementById('specialization').value,
        experience: document.getElementById('experience').value,
        address: document.getElementById('address').value,
        location: {
            type: "Point",
            coordinates: [parseFloat(document.getElementById('lng').value), parseFloat(document.getElementById('lat').value)]
        }
    };
    
    await fetch('/api/trainers', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    });
    
    bootstrap.Modal.getInstance(document.getElementById('addTrainerModal')).hide();
    fetchTrainers();
};

// Add Review
document.getElementById('addReviewForm').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
        trainerId: document.getElementById('reviewTrainerId').value,
        userName: document.getElementById('reviewUser').value,
        rating: parseInt(document.getElementById('reviewRating').value),
        comment: document.getElementById('reviewComment').value
    };
    
    await fetch('/api/reviews', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    });
    
    // Refresh details (re-open modal or just refresh list)
    bootstrap.Modal.getInstance(document.getElementById('trainerDetailsModal')).hide();
    // Ideally just refresh the reviews list in place, but closing is simple
    alert('Review Added!');
    fetchTrainers(); // Refresh main list to show new rating
};

// Search listener
document.getElementById('searchInput').addEventListener('input', (e) => {
    fetchTrainers(e.target.value);
});

// Map click to set location for registration
map.on('click', (e) => {
    document.getElementById('lat').value = e.latlng.lat;
    document.getElementById('lng').value = e.latlng.lng;
});

// Initial load
fetchTrainers();
