(function () {
    const authForm = document.getElementById('authForm');

    if (!authForm) {
        return;
    }

    const authSection = document.getElementById('authSection');
    const ctaGrid = document.getElementById('ctaGrid');
    const loggedOutHeader = document.getElementById('loggedOutHeader');
    const loggedInHeader = document.getElementById('loggedInHeader');
    const welcomeMsg = document.getElementById('welcomeMsg');
    const logoutBtn = document.getElementById('logoutBtn');
    const authTitle = document.getElementById('authTitle');
    const submitBtn = document.getElementById('submitBtn');
    const toggleAuth = document.getElementById('toggleAuth');
    const resetPasswordBtn = document.getElementById('resetPasswordBtn');
    const authMessage = document.getElementById('authMessage');
    const passHint = document.getElementById('passHint');

    const usernameGroup = document.getElementById('usernameGroup');
    const usernameInput = document.getElementById('username');
    const passwordLabel = document.getElementById('passwordLabel');
    const passwordInput = document.getElementById('password');
    const confirmPasswordGroup = document.getElementById('confirmPasswordGroup');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const nicknameGroup = document.getElementById('nicknameGroup');
    const nicknameInput = document.getElementById('nickname');
    const registerFields = document.getElementById('registerFields');
    const fullNameInput = document.getElementById('fullName');
    const mobileInput = document.getElementById('mobile');
    const ageInput = document.getElementById('age');

    let authMode = 'login';
    const isIndexPage = Boolean(authSection && ctaGrid);

    function setFieldState(input, enabled, required) {
        if (!input) {
            return;
        }

        input.disabled = !enabled;
        input.required = required;

        if (!enabled) {
            input.setCustomValidity('');
        }
    }

    function clearInputs(inputs) {
        inputs.forEach((input) => {
            if (input) {
                input.value = '';
            }
        });
    }

    function clearMessage() {
        if (!authMessage) {
            return;
        }

        authMessage.textContent = '';
        authMessage.className = 'message';
        authMessage.style.display = 'none';
    }

    function showMessage(text, type) {
        if (!authMessage) {
            return;
        }

        authMessage.textContent = text;
        authMessage.className = `message ${type}`;
        authMessage.style.display = 'block';
    }

    function updateModeUI() {
        const isLogin = authMode === 'login';
        const isRegister = authMode === 'register';
        const isReset = authMode === 'reset';

        if (authTitle) {
            authTitle.textContent = isLogin ? 'Login' : isRegister ? 'Register' : 'Reset Password';
        }

        if (submitBtn) {
            submitBtn.textContent = isLogin ? 'Login' : isRegister ? 'Register' : 'Reset Password';
        }

        if (toggleAuth) {
            toggleAuth.textContent = isLogin
                ? "Don't have an account? Register"
                : isRegister
                    ? 'Already have an account? Login'
                    : 'Back to Login';
        }

        if (resetPasswordBtn) {
            resetPasswordBtn.textContent = isLogin || isRegister
                ? 'Forgot password? Reset with nickname'
                : 'Need an account? Register';
        }

        if (usernameGroup) {
            usernameGroup.style.display = isReset ? 'none' : 'block';
        }

        if (nicknameGroup) {
            nicknameGroup.style.display = isLogin ? 'none' : 'block';
        }

        if (registerFields) {
            registerFields.style.display = isRegister ? 'block' : 'none';
        }

        if (passwordLabel) {
            passwordLabel.textContent = isReset ? 'New Password' : 'Password';
        }

        if (passwordInput) {
            passwordInput.placeholder = isReset
                ? 'Enter your new password'
                : isRegister
                    ? 'Create a password'
                    : 'Enter your password';
            passwordInput.autocomplete = isLogin ? 'current-password' : 'new-password';
        }

        if (confirmPasswordGroup) {
            confirmPasswordGroup.style.display = (isRegister || isReset) ? 'block' : 'none';
        }

        if (confirmPasswordInput) {
            confirmPasswordInput.placeholder = isReset
                ? 'Confirm your new password'
                : 'Confirm your password';
            confirmPasswordInput.autocomplete = (isRegister || isReset) ? 'new-password' : 'off';
        }

        if (passHint) {
            passHint.style.display = isRegister ? 'block' : 'none';
        }

        setFieldState(usernameInput, !isReset, !isReset);
        setFieldState(passwordInput, true, true);
        setFieldState(confirmPasswordInput, isRegister || isReset, isRegister || isReset);
        setFieldState(nicknameInput, !isLogin, !isLogin);
        setFieldState(fullNameInput, isRegister, isRegister);
        setFieldState(mobileInput, isRegister, isRegister);
        setFieldState(ageInput, isRegister, isRegister);

    }

    function checkAuth() {
        if (!isIndexPage) {
            return;
        }

        const user = JSON.parse(localStorage.getItem('user'));
        const hasUser = Boolean(user);

        if (authSection) {
            authSection.style.display = hasUser ? 'none' : 'block';
        }

        if (ctaGrid) {
            ctaGrid.style.display = hasUser ? 'grid' : 'none';
        }

        if (welcomeMsg) {
            welcomeMsg.innerText = hasUser ? `Welcome back, ${user.name || user.username}!` : '';
            welcomeMsg.style.display = hasUser ? 'block' : 'none';
        }

        if (logoutBtn) {
            logoutBtn.style.display = hasUser ? 'block' : 'none';
        }

        if (loggedOutHeader) {
            loggedOutHeader.style.display = hasUser ? 'none' : 'block';
        }

        if (loggedInHeader) {
            loggedInHeader.style.display = hasUser ? 'block' : 'none';
        }
    }

    function setMode(nextMode) {
        const previousMode = authMode;
        authMode = nextMode;
        if (confirmPasswordInput && nextMode !== previousMode) {
            confirmPasswordInput.value = '';
        }
        updateModeUI();
    }

    toggleAuth.addEventListener('click', () => {
        clearMessage();
        setMode(authMode === 'register' || authMode === 'reset' ? 'login' : 'register');
    });

    resetPasswordBtn.addEventListener('click', () => {
        clearMessage();
        setMode(authMode === 'reset' ? 'register' : 'reset');
    });

    authForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        clearMessage();

        const payload = {};

        if (authMode === 'login') {
            payload.username = usernameInput ? usernameInput.value.trim() : '';
            payload.password = passwordInput ? passwordInput.value : '';
        } else if (authMode === 'register') {
            payload.username = usernameInput ? usernameInput.value.trim() : '';
            payload.password = passwordInput ? passwordInput.value : '';
            payload.nickname = nicknameInput ? nicknameInput.value.trim() : '';
            payload.name = fullNameInput ? fullNameInput.value.trim() : '';
            payload.mobileNumber = mobileInput ? mobileInput.value.trim() : '';
            payload.age = ageInput ? Number(ageInput.value) : 0;

            if (confirmPasswordInput && payload.password !== confirmPasswordInput.value) {
                showMessage('Passwords do not match.', 'error');
                return;
            }
        } else {
            payload.nickname = nicknameInput ? nicknameInput.value.trim() : '';
            payload.newPassword = passwordInput ? passwordInput.value : '';

            if (confirmPasswordInput && payload.newPassword !== confirmPasswordInput.value) {
                showMessage('Passwords do not match.', 'error');
                if (submitBtn) {
                    submitBtn.disabled = false;
                }
                return;
            }
        }

        const endpoint = authMode === 'login'
            ? '/api/auth/login'
            : authMode === 'register'
                ? '/api/auth/register'
                : '/api/auth/reset-password';

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = authMode === 'login'
                ? 'Signing In...'
                : authMode === 'register'
                    ? 'Creating Account...'
                    : 'Resetting...';
        }

        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            if (!response.ok) {
                showMessage(result.message || 'Authentication failed.', 'error');
                return;
            }

            if (authMode === 'login') {
                localStorage.setItem('user', JSON.stringify(result));

                if (isIndexPage) {
                    authForm.reset();
                    checkAuth();
                } else {
                    window.location.href = '/user-search.html';
                }
                return;
            }

            if (authMode === 'register') {
                showMessage('Registration successful. You can now log in with your username and password.', 'success');
                clearInputs([passwordInput, nicknameInput, fullNameInput, mobileInput, ageInput, confirmPasswordInput]);
                setMode('login');
                return;
            }

            showMessage(result.message || 'Password reset successful. Log in with your nickname and new password.', 'success');
            clearInputs([passwordInput, nicknameInput, confirmPasswordInput]);
            setMode('login');
        } catch (error) {
            showMessage('Server error. Please try again.', 'error');
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
            }

            updateModeUI();
        }
    });

    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('user');
            checkAuth();
            setMode('login');
            clearMessage();
            authForm.reset();
        });
    }

    updateModeUI();
    checkAuth();
})();
