package com.yogatrainer.service;

import com.yogatrainer.model.User;
import com.yogatrainer.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        String username = clean(user.getUsername());
        String nickname = clean(user.getNickname());
        String password = clean(user.getPassword());
        String name = clean(user.getName());
        String mobileNumber = clean(user.getMobileNumber());

        if (isBlank(username)) {
            throw new RuntimeException("Username is required");
        }
        if (isBlank(nickname)) {
            throw new RuntimeException("Nickname is required");
        }
        if (isBlank(password)) {
            throw new RuntimeException("Password is required");
        }
        if (isBlank(name)) {
            throw new RuntimeException("Full name is required");
        }
        if (isBlank(mobileNumber)) {
            throw new RuntimeException("Mobile number is required");
        }
        if (user.getAge() <= 0) {
            throw new RuntimeException("Age is required");
        }

        if (userRepository.existsByUsernameIgnoreCase(username)) {
            throw new RuntimeException("Username already exists");
        }
        if (userRepository.existsByNicknameIgnoreCase(nickname)) {
            throw new RuntimeException("Nickname already exists");
        }

        user.setUsername(username);
        user.setNickname(nickname);
        user.setPassword(password);
        user.setName(name);
        user.setMobileNumber(mobileNumber);
        return userRepository.save(user);
    }

    public Optional<User> login(String username, String password) {
        String cleanedUsername = clean(username);
        String cleanedPassword = clean(password);

        if (isBlank(cleanedUsername) || isBlank(cleanedPassword)) {
            return Optional.empty();
        }

        return userRepository.findByUsernameIgnoreCaseAndPassword(cleanedUsername, cleanedPassword);
    }

    public User resetPassword(String nickname, String newPassword) {
        String recoveryNickname = clean(nickname);
        String password = clean(newPassword);

        if (isBlank(recoveryNickname)) {
            throw new RuntimeException("Nickname is required");
        }
        if (isBlank(password)) {
            throw new RuntimeException("New password is required");
        }

        User user = userRepository.findByNicknameIgnoreCase(recoveryNickname)
                .orElseThrow(() -> new RuntimeException("No account found for that nickname"));

        user.setPassword(password);
        return userRepository.save(user);
    }

    public Optional<User> findById(String id) {
        return userRepository.findById(id);
    }

    private String clean(String value) {
        return value == null ? null : value.trim();
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
