package com.yogatrainer.service;

import com.yogatrainer.model.Review;
import com.yogatrainer.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private TrainerService trainerService;

    public Review addReview(Review review) {
        Review savedReview = reviewRepository.save(review);
        updateTrainerRating(review.getTrainerId());
        return savedReview;
    }

    public List<Review> getReviewsByTrainer(String trainerId) {
        return reviewRepository.findByTrainerId(trainerId);
    }

    private void updateTrainerRating(String trainerId) {
        List<Review> allReviews = reviewRepository.findByTrainerId(trainerId);
        List<Review> topLevelReviews = allReviews.stream()
                .filter(r -> r.getParentId() == null || r.getParentId().isEmpty())
                .toList();

        if (topLevelReviews.isEmpty()) {
            trainerService.updateTrainerRating(trainerId, 0.0, 0);
            return;
        }

        double sum = topLevelReviews.stream().mapToDouble(Review::getRating).sum();
        double average = sum / topLevelReviews.size();
        trainerService.updateTrainerRating(trainerId, average, topLevelReviews.size());
    }
}
