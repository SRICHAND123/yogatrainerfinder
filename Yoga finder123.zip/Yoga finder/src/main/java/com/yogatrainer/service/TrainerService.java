package com.yogatrainer.service;

import com.yogatrainer.model.Trainer;
import com.yogatrainer.repository.TrainerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Metrics;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrainerService {

    @Autowired
    private TrainerRepository trainerRepository;

    @Autowired(required = false)
    private GoogleMapsGeocodingService googleMapsGeocodingService;

    @Autowired
    private GeocodingService geocodingService;

    public Trainer addTrainer(Trainer trainer) {
        if (trainer.getLocation() == null && trainer.getAddress() != null && !trainer.getAddress().isEmpty()) {
            String fullAddress = trainer.getAddress();
            if (trainer.getDistrict() != null && !trainer.getDistrict().isEmpty()) {
                fullAddress += ", " + trainer.getDistrict();
            }

            // Try Google Maps first (if configured), fallback to OpenStreetMap
            GeoJsonPoint location = null;
            if (googleMapsGeocodingService != null) {
                location = googleMapsGeocodingService.getCoordinates(fullAddress);
            }
            if (location == null) {
                location = geocodingService.getCoordinates(fullAddress);
            }

            if (location != null) {
                trainer.setLocation(location);
            } else {
                System.err.println("WARNING: Failed to geocode address: " + fullAddress);
            }
        }
        return trainerRepository.save(trainer);
    }

    public List<Trainer> getAllTrainers() {
        return trainerRepository.findAll();
    }

    public Optional<Trainer> getTrainerById(String id) {
        return trainerRepository.findById(id);
    }

    public List<Trainer> findTrainersNearby(double lat, double lng, double distanceKm) {
        GeoJsonPoint location = new GeoJsonPoint(lng, lat);
        Distance distance = new Distance(distanceKm, Metrics.KILOMETERS);
        return trainerRepository.findByLocationNear(location, distance);
    }

    public List<Trainer> searchTrainers(String query) {
        // Search by name, specialization, address, or district
        return trainerRepository
                .findByNameContainingIgnoreCaseOrSpecializationContainingIgnoreCaseOrAddressContainingIgnoreCaseOrDistrictContainingIgnoreCase(
                        query, query, query, query);
    }

    public void updateTrainerRating(String trainerId, double newRating, int totalReviews) {
        Optional<Trainer> trainerOpt = trainerRepository.findById(trainerId);
        if (trainerOpt.isPresent()) {
            Trainer trainer = trainerOpt.get();
            trainer.setAverageRating(newRating);
            trainer.setTotalReviews(totalReviews);
            trainerRepository.save(trainer);
        }
    }
}
