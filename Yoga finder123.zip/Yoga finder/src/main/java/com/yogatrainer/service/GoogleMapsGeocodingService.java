package com.yogatrainer.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;

@Service
public class GoogleMapsGeocodingService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    // Add this to application.properties: google.maps.api.key=YOUR_API_KEY_HERE
    @Value("${google.maps.api.key:}")
    private String apiKey;

    private static final String GOOGLE_GEOCODING_API = "https://maps.googleapis.com/maps/api/geocode/json";

    public GeoJsonPoint getCoordinates(String address) {
        // If no API key configured, return null
        if (apiKey == null || apiKey.isEmpty()) {
            System.out.println("WARNING: Google Maps API key not configured. Geocoding will not work.");
            return null;
        }

        try {
            java.net.URI url = UriComponentsBuilder.fromHttpUrl(GOOGLE_GEOCODING_API)
                    .queryParam("address", address)
                    .queryParam("key", apiKey)
                    .build()
                    .toUri();

            String response = restTemplate.getForObject(url, String.class);

            if (response != null) {
                JsonNode root = objectMapper.readTree(response);
                String status = root.get("status").asText();

                if ("OK".equals(status) && root.has("results") && root.get("results").size() > 0) {
                    JsonNode location = root.get("results").get(0).get("geometry").get("location");
                    double lat = location.get("lat").asDouble();
                    double lng = location.get("lng").asDouble();

                    System.out.println("Google Maps geocoded: " + address + " -> (" + lat + ", " + lng + ")");
                    return new GeoJsonPoint(lng, lat); // MongoDB uses (lon, lat) order
                } else {
                    System.out.println("Google Maps geocoding failed for: " + address + " - Status: " + status);
                }
            }
        } catch (Exception e) {
            System.err.println("Error geocoding address with Google Maps: " + address);
            e.printStackTrace();
        }
        return null;
    }
}
