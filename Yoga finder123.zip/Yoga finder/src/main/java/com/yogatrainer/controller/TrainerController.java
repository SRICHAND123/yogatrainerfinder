package com.yogatrainer.controller;

import com.yogatrainer.model.Trainer;
import com.yogatrainer.service.TrainerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trainers")
@CrossOrigin(origins = "*") // Allow all origins for simplicity in V1
public class TrainerController {

    @Autowired
    private TrainerService trainerService;

    @PostMapping
    public Trainer createTrainer(@RequestBody Trainer trainer) {
        return trainerService.addTrainer(trainer);
    }

    @GetMapping
    public List<Trainer> getAllTrainers() {
        return trainerService.getAllTrainers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Trainer> getTrainerById(@PathVariable String id) {
        return trainerService.getTrainerById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public List<Trainer> searchTrainers(
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(required = false, defaultValue = "10") Double radius, // km
            @RequestParam(required = false) String query) {

        if (lat != null && lng != null) {
            return trainerService.findTrainersNearby(lat, lng, radius);
        } else if (query != null && !query.isEmpty()) {
            return trainerService.searchTrainers(query);
        } else {
            return trainerService.getAllTrainers();
        }
    }
}
