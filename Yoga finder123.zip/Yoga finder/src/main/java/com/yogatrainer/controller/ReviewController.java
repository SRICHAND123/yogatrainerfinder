package com.yogatrainer.controller;

import com.yogatrainer.model.Review;
import com.yogatrainer.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "*")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping
    public Review addReview(@RequestBody Review review) {
        return reviewService.addReview(review);
    }

    @GetMapping("/trainer/{trainerId}")
    public List<Review> getReviewsByTrainer(@PathVariable String trainerId) {
        return reviewService.getReviewsByTrainer(trainerId);
    }
}
