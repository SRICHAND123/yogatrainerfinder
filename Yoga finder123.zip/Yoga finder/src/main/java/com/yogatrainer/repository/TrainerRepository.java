package com.yogatrainer.repository;

import com.yogatrainer.model.Trainer;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Point;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TrainerRepository extends MongoRepository<Trainer, String> {

    // Find trainers near a location within a distance
    List<Trainer> findByLocationNear(GeoJsonPoint location, Distance distance);

    // Basic text search (can be enhanced with regex in Service)
    // Basic text search covering Name, Specialization, Address, and District
    List<Trainer> findByNameContainingIgnoreCaseOrSpecializationContainingIgnoreCaseOrAddressContainingIgnoreCaseOrDistrictContainingIgnoreCase(
            String name, String specialization, String address, String district);
}
