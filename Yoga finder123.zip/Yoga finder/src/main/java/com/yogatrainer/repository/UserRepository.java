package com.yogatrainer.repository;

import com.yogatrainer.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface UserRepository extends MongoRepository<User, String> {
    Optional<User> findByUsernameIgnoreCaseAndPassword(String username, String password);

    Optional<User> findByNicknameIgnoreCase(String nickname);

    boolean existsByUsernameIgnoreCase(String username);

    boolean existsByNicknameIgnoreCase(String nickname);
}
