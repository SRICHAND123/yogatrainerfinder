$trainers = @(
    @{ name = "Rahul Sharma"; specialization = "Hatha Yoga"; experience = 10; phone = "9848012345"; address = "Banjara Hills"; district = "Hyderabad"; age = 35; gender = "Male" },
    @{ name = "Priya Reddy"; specialization = "Vinyasa Flow"; experience = 8; phone = "9123456789"; address = "MVP Colony"; district = "Visakhapatnam"; age = 29; gender = "Female" },
    @{ name = "Suresh Kumar"; specialization = "Ashtanga Yoga"; experience = 15; phone = "9440123456"; address = "Benz Circle"; district = "Vijayawada"; age = 42; gender = "Male" },
    @{ name = "Lakshmi Prasanna"; specialization = "Iyengar Yoga"; experience = 12; phone = "9988776655"; address = "SV University Area"; district = "Tirupati"; age = 38; gender = "Female" },
    @{ name = "Anjali Rao"; specialization = "Kundalini Yoga"; experience = 5; phone = "8877665544"; address = "Subedari"; district = "Warangal"; age = 27; gender = "Female" },
    @{ name = "Vikram Singh"; specialization = "Yin Yoga"; experience = 7; phone = "7766554433"; address = "Indiranagar"; district = "Bangalore"; age = 31; gender = "Male" },
    @{ name = "Deepika Padukone"; specialization = "Vinyasa Flow"; experience = 6; phone = "6655443322"; address = "Adyar"; district = "Chennai"; age = 30; gender = "Female" },
    @{ name = "Amitabh Bachchan"; specialization = "Hatha Yoga"; experience = 20; phone = "5544332211"; address = "Juhu"; district = "Mumbai"; age = 65; gender = "Male" },
    @{ name = "Sneha Lata"; specialization = "Ashtanga Yoga"; experience = 9; phone = "4433221100"; address = "Dwaraka Nagar"; district = "Nizamabad"; age = 34; gender = "Female" },
    @{ name = "Ravi Teja"; specialization = "Iyengar Yoga"; experience = 11; phone = "3322110099"; address = "Kothirampur"; district = "Karimnagar"; age = 36; gender = "Male" },
    @{ name = "Kavitha Reddy"; specialization = "Hatha Yoga"; experience = 4; phone = "2211009988"; address = "Wyra Road"; district = "Khammam"; age = 26; gender = "Female" },
    @{ name = "Mohan Babu"; specialization = "Vinyasa Flow"; experience = 18; phone = "1100998877"; address = "Sampath Nagar"; district = "Guntur"; age = 55; gender = "Male" },
    @{ name = "Shalini Singh"; specialization = "Ashtanga Yoga"; experience = 3; phone = "9900887766"; address = "VRC Centre"; district = "Nellore"; age = 25; gender = "Female" },
    @{ name = "Pardhu Sharma"; specialization = "Hatha Yoga"; experience = 14; phone = "8800776655"; address = "Hanamkonda"; district = "Warangal"; age = 39; gender = "Male" },
    @{ name = "Meera Bai"; specialization = "Iyengar Yoga"; experience = 16; phone = "7700665544"; address = "Connaught Place"; district = "Delhi"; age = 48; gender = "Female" }
)

foreach ($trainer in $trainers) {
    $json = $trainer | ConvertTo-Json
    Invoke-RestMethod -Uri "http://localhost:8080/api/trainers" -Method Post -Body $json -ContentType "application/json"
    Write-Host "Added trainer: $($trainer.name) in $($trainer.district)"
}
