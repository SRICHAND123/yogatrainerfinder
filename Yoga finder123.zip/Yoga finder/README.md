# Yoga Trainer Finder

A full-stack Spring Boot application to find Yoga Trainers on a map.

## Prerequisites
- Java 17+
- Maven
- MongoDB (running locally on default port 27017)

## Setup & Run

1.  **Start MongoDB**: Ensure your local MongoDB instance is running.
2.  **Build the Project**:
    ```bash
    mvn clean install
    ```
3.  **Run the Application**:
    ```bash
    mvn spring-boot:run
    ```
    Or run `src/main/java/com/yogatrainer/YogaTrainerApplication.java` from your IDE.

4.  **Access the App**:
    Open [http://localhost:8080/index.html](http://localhost:8080/index.html) in your browser.

## Features

-   **Register Trainer**: Click the "Register as Trainer" button. You can click on the map to auto-fill the location.
-   **Map View**: See all trainers as markers on the map.
-   **Search**: Filter trainers by name or specialization using the search bar.
-   **Reviews**: Click a trainer marker to view details and leave a review.

## Tech Stack

-   **Backend**: Spring Boot 3, Spring Data MongoDB
-   **Database**: MongoDB
-   **Frontend**: HTML5, Bootstrap 5, Leaflet.js (OpenStreetMap)
