import requests
import json

url = "http://localhost:8080/api/trainers"
headers = {"Content-Type": "application/json"}
data = {
    "name": "Yogi Bear",
    "specialization": "Hatha Yoga",
    "experience": 10,
    "address": "Space Needle, Seattle",
    "phone": "1234567890"
}

try:
    print(f"POSTing to {url}...")
    response = requests.post(url, headers=headers, json=data)
    print(f"Status Code: {response.status_code}")
    print(f"Response Body: {response.text}")

    if response.status_code == 200:
        print("\nSearching for 'Seattle'...")
        search_url = "http://localhost:8080/api/trainers/search?query=Seattle"
        search_response = requests.get(search_url)
        print(f"Search Status: {search_response.status_code}")
        print(f"Search Results: {search_response.text}")
        
        print("\nSearching for 'Bear'...")
        search_url2 = "http://localhost:8080/api/trainers/search?query=Bear"
        search_response2 = requests.get(search_url2)
        print(f"Search Results: {search_response2.text}")

except Exception as e:
    print(f"Error: {e}")
